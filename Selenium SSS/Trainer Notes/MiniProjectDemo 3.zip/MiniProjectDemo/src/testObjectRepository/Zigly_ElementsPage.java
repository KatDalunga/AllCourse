package testObjectRepository;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Zigly_ElementsPage {
	public static WebElement element = null;
	public static WebDriver driver;
	
	public static WebElement adBanner(WebDriver driver) {
		element =driver.findElement(By.xpath("//div[@id='desktopBannerWrapped']//button[@id='moe-dontallow_button']"));
    	return element;
    }
	public static List<WebElement> menu_Hover(WebDriver driver){
		List<WebElement> menus = driver.findElements(By.xpath(
				"//div[@class='page-wrapper']//div[@class='page-nav-section']/div[@class='navigation-links']/ul[1]/li/a[1]"));
        return menus;
	}
	public static List<WebElement> submenu_Text(WebDriver driver){
    	List<WebElement> submenustxt = driver
				.findElements(By.xpath("//a[contains(@href,'https://www.zigly.com/shop/dogs/')]//span[2]"));
    	return submenustxt;		  
    } 
	public static List<WebElement> submenu_Hover(WebDriver driver){
    	List<WebElement> submenushref = driver.findElements(By.xpath(
				"//ul[@class='level1 submenu ui-menu ui-widget ui-widget-content ui-corner-all expanded activate']/li/a"));
    	return submenushref;		  
    } 
	public static WebElement sortOptions(WebDriver driver) {
		element =driver.findElement(
				By.xpath("//div[@class='top-toolbar']//div[@class='toolbar-sorter sorter']//select[@id=\"sorter\"]"));
    	return element;
    }
    
	public static WebElement setDescOrd(WebDriver driver) {
		element =driver.findElement(By.xpath("//*[@id=\"amasty-shopby-product-list\"]/div[1]/div/div[3]/a"));
    	return element;
    }
	public static WebElement logo(WebDriver driver) {
		element =driver.findElement(By.xpath("//img[@class='logo-image']"));
    	return element;
    }
	public static WebElement searchBox(WebDriver driver) {
		element =driver.findElement(By.name("q"));
    	return element;
    }
}
