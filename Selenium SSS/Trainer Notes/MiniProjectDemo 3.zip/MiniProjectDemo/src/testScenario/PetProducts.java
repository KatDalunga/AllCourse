package testScenario;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import testObjectRepository.Zigly_ElementsPage;
import userDefinedLibraries.DriverSetup;
import userDefinedLibraries.ScreenShot;

public class PetProducts extends DriverSetup {
	public static String browser = "Edge";
	public static List<WebElement> mainmenus,submenutext,submenuHreflist;
	public static WebDriver driver;
	public static WebElement sortopt,descord,logo,searchbox,appbanner,adframe,pushads;
	
	 public static void driverconfig(String browser)
	    {
		 	//Instantiate driver 
	    	driver=DriverSetup.driverInstantiate(browser);   
	    }
	 
	    public static void handle_ads()
	    {
	    	try {
				// Take screen shot
				ScreenShot.screenShotTC(driver,"Ads and pushoff");
			} catch (IOException e) {
				e.printStackTrace();
			}
	    	//Handling ads and offer popups
	    	driver.switchTo().frame("moe-onsite-campaign-65eedc17d1c47ae2335a3bf4");
			driver.findElement(By.xpath("//*[@id=\"close-icon\"]")).click();
			
			//Switching back to the main window
			driver.switchTo().defaultContent();
			appbanner = Zigly_ElementsPage.adBanner(driver);
	    	appbanner.click();
	    }
	    public static void selectMenuandSubmenu(){   
	    	// Instantiate Action Class
			Actions actions = new Actions(driver);

			List<WebElement> mainmenus = Zigly_ElementsPage.menu_Hover(driver);
			categories: for (WebElement menu : mainmenus) {
				if (menu.getText().equalsIgnoreCase("Dogs")) {
					System.out.println("Checking Main Menu options with: Dogs");
					actions.moveToElement(menu).perform();
					List<WebElement> submenuHreflist = Zigly_ElementsPage.submenu_Hover(driver);
					List<WebElement> submenutext = Zigly_ElementsPage.submenu_Text(driver);
					for (WebElement submenu : submenutext) {
						if (submenu.getText().equalsIgnoreCase("Accessories")) {
							for (WebElement submenuHref : submenuHreflist) {
								System.out.println("Checking Sub Menu options with: Accessories");
								if (submenuHref.getAttribute("href")
										.contains("https://www.zigly.com/shop/dogs/dog-accessories.html")) {
									actions.moveToElement(submenuHref);								
									actions.click().build().perform();
									System.out.println("Has quit the outermost for-loop");
									System.out.println("Landed into Accessories page!!");
									break categories;
								}

							}
						}

					}
				}

			}
			try {
				// Take screen shot
				ScreenShot.screenShotTC(driver,"accessories_page");
			} catch (IOException e) {
				e.printStackTrace();
			}			
	    }

	    public static void clickonprice()
	    {
	    	WebElement sortopt = Zigly_ElementsPage.sortOptions(driver);
			Select select = new Select(sortopt);
			select.selectByValue("price");
			System.out.println("Selected price in sorting");
	    }
	    
	    public static void clickondescarrow()
	    {
	    	WebElement descord = Zigly_ElementsPage.setDescOrd(driver);
			descord.click();
			try {
				// Take screen shot
				ScreenShot.screenShotTC(driver,"sorted_on_Price");
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("Clicked descending order arrow");
			driver.navigate().refresh();
	    }
	    public static void clickonlogo()
	    {
	    	WebElement logo = Zigly_ElementsPage.logo(driver);
			logo.click();
			System.out.println("Clicked on Zigly logo");
	    }
	    public static void enterSearchtxt()
	    {
	    	//Enter the search text in the homepage search box
	    	WebElement searchbox = Zigly_ElementsPage.searchBox(driver);
			searchbox.sendKeys("Dog bow ties");
			System.out.println("Entered text into searchbox");
			//can add wait for search results
			
			try {
				// Take screen shot
				ScreenShot.screenShotTC(driver,"Dog_bow_ties");
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
	    public static void closeBrow()
	    {
	    	//Close the browser after all the steps of scenario
	    	driverTearDown();
	    	System.out.println("Closed the browser");
	    }
	    
	public static void main(String[] args) throws Exception {
		//PetProducts petprod = new PetProducts();
		driverconfig(browser);
		handle_ads();
		selectMenuandSubmenu();
		clickonprice();
		clickondescarrow();
		clickonlogo();
		enterSearchtxt();
		closeBrow();
	}
}
