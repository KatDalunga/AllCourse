 Detailed Description:
 ====================
  1.Navigate to Be. Cognizant Website and capture the user information.
  2.Under Company Header Click on Acronyms.
  3.Verify Acronyms is displayed and Get Tool Tip.
  4.Print the count of Acronyms data.
  5.Get all data of Acronyms present in Acronym App.
  6.Click on be.Cognizant and Verify it got redirected to Be. Cognizant Home Page.
  7.Validate cognizant stock price present in Be. Cognizant page with the Google Data.
  8.Verify the same Stock Prize is present in any other years or Month.

 Key Automation Scope:
 ====================
 .Handling alert, different browser windows, search option
 .Navigating back to home page
 .Extract multiple options items & store in collections.
 .Capture warning message
 .Data Driven approach.
 .Cross Browser Testing
 
 Tools and Technology
 ====================
 	.Maven
 	.ApachePOI
 	.TestNG
 
 Output: [Chrome and Edge]
 ==================
  Be.Cognizant Page Loaded.
  Clicked on Company Header.
  Selected Acronyms.
  Acronyms is Displayed.
  Tool Tip is : Acronyms
  Printing the Count of Acronyms Data: 244
  All Data is Printed.
  Went Back to Be.Cognizant Page.
  Home Page is Verified.
  Present Stock Price is Printed.
  Stock Price is Verified with Previous Stocks Data Which is present in any other years or Month.
  
 Jar Files:
 ==========
 <dependencies>
  <!-- https://mvnrepository.com/artifact/org.seleniumhq.selenium/selenium-java -->
  <dependency>
    <groupId>org.seleniumhq.selenium</groupId>
    <artifactId>selenium-java</artifactId>
    <version>4.18.1</version>
  </dependency>

<!-- https://mvnrepository.com/artifact/io.github.bonigarcia/webdrivermanager -->
  <dependency>
    <groupId>io.github.bonigarcia</groupId>
    <artifactId>webdrivermanager</artifactId>
    <version>5.7.0</version>
  </dependency>
<!-- https://mvnrepository.com/artifact/org.apache.poi/poi -->
  <dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi</artifactId>
    <version>5.2.5</version>
  </dependency>
<!-- https://mvnrepository.com/artifact/org.apache.poi/poi-ooxml -->
  <dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi-ooxml</artifactId>
    <version>5.2.5</version>
  </dependency>

<!-- https://mvnrepository.com/artifact/org.testng/testng -->
  <dependency>
    <groupId>org.testng</groupId>
    <artifactId>testng</artifactId>
    <version>7.9.0</version>
    <scope>test</scope>
  </dependency>

  <dependency>
	<groupId>org.slf4j</groupId>
	<artifactId>slf4j-api</artifactId>
	<version>2.1.0-alpha1</version>
  </dependency>

<!-- https://mvnrepository.com/artifact/com.aventstack/extentreports -->
  <dependency>
    <groupId>com.aventstack</groupId>
    <artifactId>extentreports</artifactId>
    <version>5.0.9</version>
  </dependency>
 </dependencies>
  
  